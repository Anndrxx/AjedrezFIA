package com.chess;

import com.chess.gui.Table;

public class BlackWidow {

    public static void main(final String[] args) throws Exception {
        Table.get().show();
    }
}
