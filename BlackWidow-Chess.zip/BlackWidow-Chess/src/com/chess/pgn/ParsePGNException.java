package com.chess.pgn;

public class ParsePGNException
        extends Exception {

    public ParsePGNException(final String message) {
        super(message);
    }

}
